<?php
/*
 * NTeam
 * @package mod_nteam
 * @license GNU/GPL, see LICENSE.txt
 * Author: Nitish Gundherva
 */
defined( '_JEXEC' ) or die( 'Restricted access' ); 
class modTeamHelper
{
    /**
     *
     * @param array $params An object containing the module parameters
     * @access public
     */    
    public static function getTeam(  )
    {
        return ;
    }
}
?>